import argparse
import json
import re
from collections import defaultdict
from pathlib import Path


SECTION_RE = re.compile(r"^(第[一二三四五六七八九十百]+[篇章]\s*[^\n]{1,20})$")
QUESTION_RE = re.compile(r"(?m)^\s*(\d{1,4})[\.．、]\s*(?=\S)")
ANSWER_RE = re.compile(r"(?m)^\s*(\d{1,4})[\.．、]\s*[【\[]?答案[】\]]?\s*([ABCD])")
OPTION_RE = re.compile(r"(?m)^\s*([ABCD])[\.．、]\s*")
SECTION_KEYWORDS = [
    "片段阅读", "语句表达", "逻辑填空", "篇章阅读",
    "图形推理", "定义判断", "类比推理", "逻辑判断",
    "数学运算", "数字推理", "资料分析", "常识判断"
]


def load_pages(path):
    rows = []
    with Path(path).open("r", encoding="utf-8") as stream:
        for line in stream:
            rows.append(json.loads(line))
    return sorted(rows, key=lambda row: row["page"])


def clean_line(line):
    line = line.strip().replace("（)", "（）").replace("(）", "（）")
    if not line or line == "?" or re.fullmatch(r"\d{1,3}", line):
        return ""
    if any(token in line for token in ["更多资料添加", "feifeixuejie", "粉笔事考"]):
        return ""
    return line


def canonical_section(value):
    normalized = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", "", value)
    for keyword in SECTION_KEYWORDS:
        if keyword in normalized:
            return keyword
    return normalized


def collect_sections(pages):
    sections = defaultdict(list)
    current = "未分类"
    for page in pages:
        kept = []
        for raw in page.get("text", "").splitlines():
            line = clean_line(raw)
            if not line:
                continue
            compact_header = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", "", line)
            detected_keyword = next((keyword for keyword in SECTION_KEYWORDS if keyword in compact_header), None)
            if detected_keyword and len(compact_header) <= 24:
                current = detected_keyword
                continue
            match = SECTION_RE.match(line)
            if match:
                candidate = canonical_section(match.group(1))
                is_generic_part_header = "篇" in candidate and not any(keyword in candidate for keyword in SECTION_KEYWORDS)
                if not is_generic_part_header or current == "未分类":
                    current = candidate
                continue
            kept.append(line)
        if kept:
            sections[current].append("\n".join(kept))
    return {key: "\n".join(value) for key, value in sections.items()}


def compact(text):
    value = re.sub(r"\s+", "", text).strip()
    value = re.sub(r"[^。！？]{0,24}打开粉笔APP.*?扫码[。.]?", "", value)
    value = re.sub(r"学[^。！？]{0,24}APP[。.]?", "", value)
    value = re.sub(r"更多资料添加[:：]?[^。！？]{0,40}", "", value)
    return value.strip()


def parse_questions(sections):
    questions = {}
    for section, text in sections.items():
        starts = list(QUESTION_RE.finditer(text))
        for index, match in enumerate(starts):
            number = int(match.group(1))
            segment = text[match.end():starts[index + 1].start() if index + 1 < len(starts) else len(text)]
            options = list(OPTION_RE.finditer(segment))
            if len(options) < 4 or [item.group(1) for item in options[:4]] != list("ABCD"):
                continue
            prompt = compact(segment[:options[0].start()])
            values = []
            for option_index, option in enumerate(options[:4]):
                end = options[option_index + 1].start() if option_index + 1 < 4 else len(segment)
                values.append(compact(segment[option.end():end]))
            if len(prompt) < 8 or any(len(value) < 1 for value in values):
                continue
            questions[(section, number)] = {"section": section, "number": number, "prompt": prompt, "options": values}
    return questions


def parse_answers(sections):
    answers = {}
    for section, text in sections.items():
        starts = list(ANSWER_RE.finditer(text))
        for index, match in enumerate(starts):
            number = int(match.group(1))
            answer = match.group(2)
            segment = text[match.end():starts[index + 1].start() if index + 1 < len(starts) else len(text)]
            explanation = segment.split("【解析】", 1)[-1]
            explanation = compact(explanation)
            if len(explanation) < 8:
                explanation = "详见原题解析。"
            answers[(section, number)] = {"answer": answer, "explanation": explanation}
    return answers


def subject_for(section):
    if any(token in section for token in ["言语", "片段阅读", "语句表达", "逻辑填空", "篇章阅读"]):
        return "言语理解"
    if any(token in section for token in ["判断", "图形推理", "定义判断", "类比推理", "逻辑判断"]):
        return "判断推理"
    if any(token in section for token in ["数量", "数学运算", "数字推理"]):
        return "数量关系"
    if "资料" in section:
        return "资料分析"
    if "常识" in section:
        return "常识判断"
    return "职业能力测验"


def sql_text(value):
    return "'" + str(value).replace("'", "''") + "'"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("questions")
    parser.add_argument("answers")
    parser.add_argument("output_sql")
    parser.add_argument("report")
    args = parser.parse_args()

    question_sections = collect_sections(load_pages(args.questions))
    answer_sections = collect_sections(load_pages(args.answers))
    questions = parse_questions(question_sections)
    answers = parse_answers(answer_sections)

    matched = []
    for key, question in questions.items():
        answer = answers.get(key)
        if not answer:
            continue
        matched.append({**question, **answer})

    output_path = Path(args.output_sql)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("-- OCR import from the supplied question and answer volumes.\n")
        stream.write("-- Generated rows are idempotent through question_bank.source_key.\n")
        for item in matched:
            section_key = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", "-", item["section"]).strip("-")
            source_key = f"fenbi-{section_key}-{item['number']:04d}"
            correct = "ABCD".index(item["answer"])
            values = [source_key, subject_for(item["section"]), item["section"], item["number"], item["prompt"], *item["options"], correct, item["explanation"], "职业能力倾向测验1000题"]
            encoded = ", ".join(str(value) if isinstance(value, int) else sql_text(value) for value in values)
            stream.write("INSERT OR IGNORE INTO question_bank (source_key, subject, section, question_no, prompt, option_a, option_b, option_c, option_d, correct_answer, explanation, source_name) VALUES (" + encoded + ");\n")

    report = {
        "question_pages": len(load_pages(args.questions)),
        "answer_pages": len(load_pages(args.answers)),
        "questions_parsed": len(questions),
        "answers_parsed": len(answers),
        "matched_rows": len(matched),
        "question_sections": sorted(question_sections),
        "answer_sections": sorted(answer_sections),
        "unmatched_question_count": len(set(questions) - set(answers)),
    }
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
