import sqlite3
from pathlib import Path


database = sqlite3.connect(":memory:")
for migration in [
    "drizzle/0000_student_records.sql",
    "drizzle/0001_payment_placeholders.sql",
    "drizzle/0002_daily_question_bank.sql",
    "drizzle/0003_ocr_question_bank.sql",
]:
    database.executescript(Path(migration).read_text(encoding="utf-8"))

total = database.execute("SELECT COUNT(*) FROM question_bank").fetchone()[0]
ocr = database.execute("SELECT COUNT(*) FROM question_bank WHERE source_name = ?", ("职业能力倾向测验1000题",)).fetchone()[0]
invalid = database.execute("""SELECT COUNT(*) FROM question_bank
    WHERE LENGTH(prompt) < 8 OR LENGTH(option_a) < 1 OR LENGTH(option_b) < 1
    OR LENGTH(option_c) < 1 OR LENGTH(option_d) < 1 OR correct_answer NOT BETWEEN 0 AND 3""").fetchone()[0]
if total < 100 or ocr < 100 or invalid:
    raise SystemExit(f"question migration validation failed: total={total}, ocr={ocr}, invalid={invalid}")

sets = []
for date in ["2026-11-10", "2026-11-11", "2026-11-12"]:
    seed = int(date.replace("-", ""))
    ids = [row[0] for row in database.execute("SELECT id FROM question_bank WHERE active = 1 ORDER BY id")]
    for index in range(len(ids) - 1, 0, -1):
        seed = (seed * 1664525 + 1013904223) & 0xFFFFFFFF
        swap_index = seed % (index + 1)
        ids[index], ids[swap_index] = ids[swap_index], ids[index]
    ids = tuple(ids[:5])
    if len(ids) != 5:
        raise SystemExit(f"daily selection failed for {date}")
    sets.append(ids)
if len(set(sets)) != len(sets):
    raise SystemExit(f"daily selections did not change: {sets}")

subjects = database.execute("SELECT subject, COUNT(*) FROM question_bank GROUP BY subject ORDER BY subject").fetchall()
print(f"Question migration test passed: total={total}, ocr={ocr}, subjects={subjects}, daily_sets={sets}")
