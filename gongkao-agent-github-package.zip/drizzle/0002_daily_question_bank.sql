CREATE TABLE IF NOT EXISTS question_bank (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_key TEXT NOT NULL UNIQUE,
  subject TEXT NOT NULL,
  section TEXT,
  question_no INTEGER,
  prompt TEXT NOT NULL,
  option_a TEXT NOT NULL,
  option_b TEXT NOT NULL,
  option_c TEXT NOT NULL,
  option_d TEXT NOT NULL,
  correct_answer INTEGER NOT NULL CHECK (correct_answer BETWEEN 0 AND 3),
  explanation TEXT NOT NULL,
  source_name TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS daily_question_sets (
  study_date TEXT NOT NULL,
  position INTEGER NOT NULL CHECK (position BETWEEN 0 AND 4),
  question_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (study_date, position),
  UNIQUE (study_date, question_id),
  FOREIGN KEY (question_id) REFERENCES question_bank(id)
);

CREATE TABLE IF NOT EXISTS daily_progress (
  user_id TEXT NOT NULL,
  study_date TEXT NOT NULL,
  question_id INTEGER NOT NULL,
  selected_answer INTEGER NOT NULL CHECK (selected_answer BETWEEN 0 AND 3),
  is_correct INTEGER NOT NULL DEFAULT 0,
  answered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, study_date, question_id),
  FOREIGN KEY (user_id) REFERENCES students(user_id) ON DELETE CASCADE,
  FOREIGN KEY (question_id) REFERENCES question_bank(id)
);

CREATE INDEX IF NOT EXISTS idx_daily_progress_user_date ON daily_progress(user_id, study_date);
CREATE INDEX IF NOT EXISTS idx_daily_sets_date ON daily_question_sets(study_date, position);
CREATE INDEX IF NOT EXISTS idx_question_bank_active ON question_bank(active, id);

INSERT OR IGNORE INTO question_bank
  (id, source_key, subject, section, question_no, prompt, option_a, option_b, option_c, option_d, correct_answer, explanation, source_name)
VALUES
  (1, 'demo-001', '言语理解', '选词填空', 1, '在长期的艺术创作中，艺术家逐渐形成了自己的风格。真正成熟的艺术风格，并非对某种形式的简单重复，而是在不断变化中保持内在精神的____。填入横线最恰当的一项是：', '稳定性', '独特性', '一致性', '延续性', 2, '文段强调“在不断变化中保持”某种内在精神，最能体现前后统一的是“一致性”。', '演示题库'),
  (2, 'demo-002', '判断推理', '逻辑判断', 2, '所有参加面试的考生都通过了资格审查，小王没有通过资格审查。由此可以推出：', '小王没有参加面试', '小王参加了笔试', '小王未报名考试', '小王笔试成绩不合格', 0, '“参加面试 → 通过资格审查”，小王未通过资格审查，根据逆否命题可推出小王没有参加面试。', '演示题库'),
  (3, 'demo-003', '数量关系', '基础计算', 3, '某单位组织30人参加培训，第一天到场人数占总人数的80%，第二天又有3人到场。第二天到场人数占总人数的比例为：', '85%', '88%', '90%', '95%', 2, '第一天到场30×80%=24人，第二天增加3人，共27人，占30人的90%。', '演示题库'),
  (4, 'demo-004', '常识判断', '国家机构', 4, '下列关于我国国家机关职权的说法，正确的是：', '人民法院依法行使检察权', '人民检察院依法行使审判权', '全国人民代表大会是最高国家权力机关', '国务院是国家最高权力机关', 2, '全国人民代表大会是最高国家权力机关；法院行使审判权，检察院行使检察权。', '演示题库'),
  (5, 'demo-005', '言语理解', '选词填空', 5, '数字技术为文化遗产保护提供了新的可能，但技术的应用不能____文化本身的价值判断。填入横线最恰当的一项是：', '代替', '干扰', '削弱', '回避', 0, '技术是工具，不能取代对文化本身的价值判断。“代替”最符合语义和搭配。', '演示题库');
