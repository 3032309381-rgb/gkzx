import worker from "../dist/server/index.js";

const bank = Array.from({ length: 8 }, (_, index) => ({
  id: index + 1,
  subject: "测试模块",
  section: "测试章节",
  prompt: `测试题目${index + 1}`,
  option_a: "A项",
  option_b: "B项",
  option_c: "C项",
  option_d: "D项",
  correct_answer: index % 4,
  explanation: "测试解析"
}));
const sets = [];
const progress = [];

function statement(sql) {
  return {
    args: [],
    bind(...args) { this.args = args; return this; },
    async run() {
      if (sql.includes("INSERT OR IGNORE INTO daily_question_sets")) {
        const [study_date, position, question_id] = this.args;
        if (!sets.some(row => row.study_date === study_date && row.position === position)) sets.push({ study_date, position, question_id });
      }
      if (sql.includes("INSERT INTO daily_progress")) progress.push(this.args);
      return { success: true };
    },
    async first() {
      if (sql.includes("COUNT(*) AS count FROM daily_question_sets")) return { count: sets.filter(row => row.study_date === this.args[0]).length };
      if (sql.includes("SELECT q.correct_answer FROM daily_question_sets")) {
        const found = sets.find(row => row.study_date === this.args[0] && row.question_id === this.args[1]);
        return found ? { correct_answer: bank.find(item => item.id === found.question_id).correct_answer } : null;
      }
      return {};
    },
    async all() {
      if (sql.includes("SELECT id FROM question_bank")) return { results: bank.slice(0, 5).map(item => ({ id: item.id })) };
      if (sql.includes("FROM daily_question_sets d JOIN question_bank q")) {
        const studyDate = this.args[1];
        return { results: sets.filter(row => row.study_date === studyDate).sort((a, b) => a.position - b.position).map(row => { const item = bank.find(value => value.id === row.question_id); return { ...item, text: item.prompt, answer: item.correct_answer, explain: item.explanation, position: row.position, selected_answer: null }; }) };
      }
      return { results: [] };
    }
  };
}

const env = { DB: { prepare: statement, batch: statements => Promise.all(statements.map(item => item.run())) } };
const headers = { "oai-authenticated-user-id": "test-user", "oai-authenticated-user-email": "test@example.com" };
const dailyResponse = await worker.fetch(new Request("https://example.test/api/daily-questions", { headers }), env);
const daily = await dailyResponse.json();
if (dailyResponse.status !== 200 || daily.questions?.length !== 5 || !/^\d{4}-\d{2}-\d{2}$/.test(daily.studyDate)) throw new Error("daily question endpoint failed");

const first = daily.questions[0];
const progressResponse = await worker.fetch(new Request("https://example.test/api/progress", {
  method: "POST",
  headers: { ...headers, "content-type": "application/json" },
  body: JSON.stringify({ questionId: first.id, selectedAnswer: first.answer })
}), env);
const saved = await progressResponse.json();
if (progressResponse.status !== 200 || !saved.isCorrect || progress.length !== 1) throw new Error(`daily progress endpoint failed: ${progressResponse.status} ${JSON.stringify(saved)} rows=${progress.length}`);
console.log(`Daily question test passed for ${daily.studyDate} (Asia/Shanghai)`);
