import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const html = fs.readFileSync(path.join(root, "dist/index.html"), "utf8")
  .replace('  <link rel="stylesheet" href="overrides.css" />\n', '')
  .replace('  <script src="app-v2.js"></script>\n', '');
const css = fs.readFileSync(path.join(root, "dist/styles.css"), "utf8") + "\n" + fs.readFileSync(path.join(root, "dist/overrides.css"), "utf8");
const js = fs.readFileSync(path.join(root, "dist/app.js"), "utf8") + "\n" + fs.readFileSync(path.join(root, "dist/app-v2.js"), "utf8");
const hero = fs.readFileSync(path.join(root, "dist/assets/study-hero-v2.png")).toString("base64");
const shell = fs.readFileSync(path.join(root, "worker/index.template.js"), "utf8");
const built = shell
  .replace("__HTML_B64__", Buffer.from(html).toString("base64"))
  .replace("__CSS_B64__", Buffer.from(css).toString("base64"))
  .replace("__JS_B64__", Buffer.from(js).toString("base64"))
  .replace("__HERO_B64__", hero);

fs.mkdirSync(path.join(root, "dist/server"), { recursive: true });
fs.mkdirSync(path.join(root, "dist/.openai/drizzle"), { recursive: true });
fs.copyFileSync(path.join(root, ".openai/hosting.json"), path.join(root, "dist/.openai/hosting.json"));
for (const migration of fs.readdirSync(path.join(root, "drizzle")).filter(file => file.endsWith(".sql"))) {
  fs.copyFileSync(path.join(root, "drizzle", migration), path.join(root, "dist/.openai/drizzle", migration));
}
fs.writeFileSync(path.join(root, "dist/server/index.js"), built);
console.log("Worker build ready: dist/server/index.js");
